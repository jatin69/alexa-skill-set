# Feature discussion


## MAJOR
- US|INDIA and world mode
- feature to store already used places

- repeat what just alexa said
- feature to spell it out
- feature to ask more details about that place

## ADD ONS

- make instructions more clear, let them know new delhi in india is also valid => REAL POWER
- tell province along with city as cities told by are confusing