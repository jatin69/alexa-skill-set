# Feature discussion

- remove dynamo DB stuff
- remove long speech from initial intro

- verify billing on google 

- writeup for skill publishing

- [mostly done] clean code and reformat
- [content] add flash cards content for echo show
- [content] let users know new "delhi in india" is also valid => REAL POWER users are allowed to say a city name with country name as well.
- [content] make instructions more clear & add proper SSML


## done

- [done - defeat] i accept defeat intent
- [done - spell] spell out the place spelling
- [done - lifelines] can skip current : 3 lifelines implement located In in the lifeline
- [done] Implement restart : what will happen if i try to invoke the skill within a session ?
- [done] end session - restart 
- [done] repeat what just alexa said =>> The place name or whatever ==>> maybe 
- [done] only allow countries with characters (Alphabets only) => mainly last letter character =>> isalpha
- [done] country mode (verify user just said country => same map stuff) and world mode TWO MODES => MAJOR UPDATE
- [done] feature to store already used places 
- [done] Note that- calculate alpha2Code for a country mode only once per session.
- [done for now] add more utterances to intents => spelling, know more, lifeline and all others.
- [done for now] last letter + (Random) =>> be smart about this random boy
- [done for now - computer's defeat] computer looses when no result is found for that regions. 
- [done] make spelling sound even better A. S. I. A.
- [done] it is located in PA, USA ==>> find a way to make it PA as Pennsylvania
- [done] change name to atlas adventure
- [done] add RE PICKING add exit condition
- [no problem yet] add support for multiple languages


## ADD ONS

- [later maybe] add one more slot for additional data => can add infinite shit => lol => but later
- [very later] user profile ??? dynamoDB stuff => maybe

- [not required] alexa guesses a city with lenght >=3 =>> code implementation
- [what?] how to prevent too soon access of intents [later] ?? wait what ?
- [maybe] make separate repo for this skill - link other repo - but history will be lost	

- [later maybe - know more intent] feature to ask more details about that place => along with its state and country
  so that user can remember the place next time. => using place ID
