var str = "D.C.";
str = str.replace(/[^a-zA-Z ]/g, "");
console.log(str);